-- DecodeLabs | Data Analytics | Project 3: SQL Data Analysis
-- Table: orders (1,200 rows) | Dialect: SQLite (works in MySQL except strftime; use YEAR(Date) there)

-- Q1. Preview the data
-- Question: Look at the first 10 orders to understand the table structure.
-- Insight: The table has one row per order with product, price, status and payment details.
SELECT OrderID, Date, Product, Quantity, UnitPrice, OrderStatus, TotalPrice
FROM orders
LIMIT 10;

-- Q2. Total orders, revenue and average order value
-- Question: Overall size of the business (COUNT, SUM, AVG).
-- Insight: 1,200 orders generated about 1.26M in total revenue, an average of 1,053.97 per order (all statuses included).
SELECT COUNT(*) AS total_orders,
       ROUND(SUM(TotalPrice), 2) AS total_revenue,
       ROUND(AVG(TotalPrice), 2) AS avg_order_value
FROM orders;

-- Q3. Orders by status
-- Question: How many orders sit in each status? (GROUP BY + COUNT + ORDER BY)
-- Insight: Orders are spread almost evenly across statuses. Cancelled (250) and Returned (247) together make up about 41% of orders, so a large share of revenue is lost.
SELECT OrderStatus, COUNT(*) AS num_orders
FROM orders
GROUP BY OrderStatus
ORDER BY num_orders DESC;

-- Q4. Top 10 highest-value delivered orders
-- Question: Filter with WHERE, sort with ORDER BY.
-- Insight: Tablets, Printers, Laptops and Chairs fill the top spots; every top-10 delivered order has a quantity of 4 or 5.
SELECT OrderID, Product, Quantity, TotalPrice, PaymentMethod
FROM orders
WHERE OrderStatus = 'Delivered'
ORDER BY TotalPrice DESC
LIMIT 10;

-- Q5. Revenue by product (excluding cancelled and returned)
-- Question: Which products earn the most real revenue?
-- Insight: Printer (120,998) and Chair (120,321) lead net revenue. Phone is lowest at 94,535.
SELECT Product,
       COUNT(*) AS num_orders,
       SUM(Quantity) AS units_sold,
       ROUND(SUM(TotalPrice), 2) AS revenue,
       ROUND(AVG(TotalPrice), 2) AS avg_order_value
FROM orders
WHERE OrderStatus NOT IN ('Cancelled', 'Returned')
GROUP BY Product
ORDER BY revenue DESC;

-- Q6. Percentage contribution of each product to net revenue
-- Question: Share of total revenue per product.
-- Insight: Printer and Chair each contribute about 16% of net revenue; Phone contributes about 12.7%.
SELECT Product,
       ROUND(SUM(TotalPrice), 2) AS revenue,
       ROUND(100.0 * SUM(TotalPrice) /
             (SELECT SUM(TotalPrice) FROM orders
              WHERE OrderStatus NOT IN ('Cancelled', 'Returned')), 2) AS pct_of_revenue
FROM orders
WHERE OrderStatus NOT IN ('Cancelled', 'Returned')
GROUP BY Product
ORDER BY revenue DESC;

-- Q7. Average order value by payment method
-- Question: Do customers spend more with certain payment methods?
-- Insight: Credit Card orders have the highest average value (1,127.55); Debit Card the lowest (1,001.56).
SELECT PaymentMethod,
       COUNT(*) AS num_orders,
       ROUND(AVG(TotalPrice), 2) AS avg_order_value
FROM orders
GROUP BY PaymentMethod
ORDER BY avg_order_value DESC;

-- Q8. Revenue by referral source
-- Question: Which marketing channels bring in the most net revenue?
-- Insight: Instagram brings the most net revenue (175,506), followed by Google and Email. Referral is the weakest channel.
SELECT ReferralSource,
       COUNT(*) AS num_orders,
       ROUND(SUM(TotalPrice), 2) AS revenue
FROM orders
WHERE OrderStatus NOT IN ('Cancelled', 'Returned')
GROUP BY ReferralSource
ORDER BY revenue DESC;

-- Q9. Coupon usage and NULL handling
-- Question: COUNT(*) counts every row, COUNT(column) skips NULLs. Shows orders with and without a coupon.
-- Insight: 309 orders (25.75%) have no coupon. COUNT(*) returns 1,200 while COUNT(CouponCode) returns 891.
SELECT COUNT(*) AS all_orders,
       COUNT(CouponCode) AS orders_with_coupon,
       COUNT(*) - COUNT(CouponCode) AS orders_without_coupon
FROM orders;

-- Q10. Orders and average value by coupon code
-- Question: COALESCE labels the NULL group so it appears in the result.
-- Insight: Coupon orders and non-coupon orders have very similar average values (about 1,036 to 1,070), so coupons do not seem to change basket size.
SELECT COALESCE(CouponCode, 'No coupon') AS coupon,
       COUNT(*) AS num_orders,
       ROUND(AVG(TotalPrice), 2) AS avg_order_value
FROM orders
GROUP BY COALESCE(CouponCode, 'No coupon')
ORDER BY num_orders DESC;

-- Q11. Yearly revenue and orders
-- Question: Trend over time using strftime on the Date column.
-- Insight: Net revenue fell from 330,548 (2023) to 300,340 (2024). 2025 covers only Jan to Jun, so it is not a full-year comparison.
SELECT strftime('%Y', Date) AS year,
       COUNT(*) AS num_orders,
       ROUND(SUM(TotalPrice), 2) AS revenue
FROM orders
WHERE OrderStatus NOT IN ('Cancelled', 'Returned')
GROUP BY year
ORDER BY year;

-- Q12. Products with a high cancellation or return count (HAVING)
-- Question: HAVING filters groups after aggregation: products with more than 70 cancelled or returned orders.
-- Insight: Tablet, Laptop, Printer, Chair and Monitor each have more than 70 cancelled or returned orders; Tablet is highest at 77.
SELECT Product, COUNT(*) AS cancelled_or_returned
FROM orders
WHERE OrderStatus IN ('Cancelled', 'Returned')
GROUP BY Product
HAVING COUNT(*) > 70
ORDER BY cancelled_or_returned DESC;

-- Q13. Large orders (quantity 4 or more) paid by credit card
-- Question: Combining conditions with AND.
-- Insight: Orders of 4 to 5 units paid by credit card reach up to 3,299 per order.
SELECT OrderID, Product, Quantity, TotalPrice
FROM orders
WHERE Quantity >= 4 AND PaymentMethod = 'Credit Card'
ORDER BY TotalPrice DESC
LIMIT 10;

-- Q14. Customers with more than one order
-- Question: Repeat customers via GROUP BY + HAVING.
-- Insight: Only a few customers ordered twice; no customer ordered more than twice, so repeat purchasing is very low.
SELECT CustomerID, COUNT(*) AS num_orders, ROUND(SUM(TotalPrice), 2) AS total_spent
FROM orders
GROUP BY CustomerID
HAVING COUNT(*) > 1
ORDER BY num_orders DESC, total_spent DESC
LIMIT 10;

